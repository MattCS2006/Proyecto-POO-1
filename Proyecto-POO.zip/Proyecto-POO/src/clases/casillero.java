package clases;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author masan
 */
public class casillero {

    private int id;  // Añadimos el ID
    private String counter;
    private cliente cliente;
    private boolean estado;
    private List<entregable> entregables;

    // Constructor por defecto
    public casillero() {
        this.entregables = new ArrayList<>();
    }

    // Constructor con ID y otros atributos
    public casillero(int id, String counter, cliente cliente, boolean estado) {
        this.id = id;  // Asignar el ID en el constructor
        this.counter = counter;
        this.cliente = cliente;
        this.estado = estado;
        this.entregables = new ArrayList<>();
    }

    // Getters y Setters para ID
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Getters y Setters para los demás atributos
    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
    }

    public cliente getCliente() {
        return cliente;
    }

    public void setCliente(cliente cliente) {
        this.cliente = cliente;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public List<entregable> getEntregables() {
        return entregables;
    }

    public void setEntregables(List<entregable> entregables) {
        this.entregables = entregables;
    }

    // Método para agregar un paquete a la colección
    public void addEntregable(entregable entregable) {
        this.entregables.add(entregable);
    }
}
